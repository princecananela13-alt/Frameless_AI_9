# Frameless_AI launcher (APK source)

Opens the Frameless_AI WebUI in its own app, with root access built in.
Needs: rooted phone + the Frameless_AI Magisk module installed.
The UI shown is the v1.2 copy bundled in `app/src/main/assets/index.html` (same as the module's `webroot/index.html`). Needs the v1.2 module installed.
